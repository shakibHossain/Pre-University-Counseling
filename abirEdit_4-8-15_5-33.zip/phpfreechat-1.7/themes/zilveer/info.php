<?php
$aka = ""zilveer;
$author = "Name: Isa Acar";
$date = "10th Oct-2006";
$mail = "zilveer@gmail.com";
?>